import Funds.PensionFund;

import java.io.*;
import java.util.List;
import java.util.Random;

public class FundGenerator {
    public static void main(String[] args) throws IOException {

        Random random = new Random();


        File fund = new File("Fund.txt");
        File generatedFund = new File("GeneratedFunds.txt");

        FileReader fileReader = new FileReader(fund);
        FileWriter fileWriter = new FileWriter(generatedFund);

        BufferedReader bufferedReader = new BufferedReader(fileReader);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

        List<String> fundNames = bufferedReader.lines().toList();

        for (String fundName : fundNames) {
            boolean states = !fundName.contains("private");
            String fundInfo = fundName + ", " + states;
            bufferedWriter.write(fundInfo);
            bufferedWriter.newLine();
        }
        bufferedWriter.flush();
    }


    public List<PensionFund> generatePensionFund() {
       return generatePensionFund();
    }
}
