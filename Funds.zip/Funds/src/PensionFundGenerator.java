

import Funds.PensionFund;

import java.io.*;
import java.util.List;

public class PensionFundGenerator {

        static File generatedFund = new File("GeneratedFunds.txt");


        static FileReader fileReader;

    static {
            try {
                fileReader = new FileReader(generatedFund);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
        }


        static BufferedReader bufferedReader = new BufferedReader(fileReader);

        public static List<PensionFund> generatedFunds(){
            List<PensionFund> funds = bufferedReader.lines()
                    .map(string -> {
                        try {
                            return new PensionFund(string);
                        } catch (FileNotFoundException e) {
                            e.printStackTrace();
                        }
                        return null;
                    })
                    .toList();
            return funds;

        }

    }
