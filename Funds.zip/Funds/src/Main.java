import Funds.PensionFund;
import Funds.Worker;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    private static Object Worker;

    public static void main(String[] args) throws IOException {
        /*
а) Найдите фонд, где больше всего вложенцев
б) Найдите имя человека, у которого самая большая пенсия
в) Найдите людей, которые стали жертвами "не государственных фондов"
г) Найдите среднюю пенсию по фондам
д) Найдите среднюю пенсию по людям
е) Найдите наибольшую пенсию среди людей до 25
ё) Найдите самого молодого человека среди вложенцев гос. фондов
         */


    FundGenerator generatorFunds = new FundGenerator();
    List<PensionFund> pensionFunds = generatorFunds.generatePensionFund();

    PensionFund mostPopularFund = pensionFunds.stream()
            .filter(Objects::nonNull)
            .max(Comparator.comparingInt(fund-> fund.getPersons().size()))
            .orElse(null);
    System.out.println(mostPopularFund);

    Worker namePensioner = pensionFunds.stream()
            .filter(Objects::nonNull)
            .map(fund -> fund.getPersons())
            .flatMap(workers -> workers.stream())
            .max(Comparator.comparingDouble(worker -> worker.calculatePension()))
            .orElse(null);
    System.out.println(namePensioner);

    List <Worker> lozers = pensionFunds.stream()
            .filter(Objects::nonNull)
            .filter(fund -> !fund.isGovernmental())
            .flatMap(fund -> fund.getPersons().stream())
            .toList();
    System.out.println(lozers.size());

    List <Double> pensionList = pensionFunds.stream()
            .filter(Objects::nonNull)
            .flatMap(fund -> fund.getPersons().stream())
            .map(worker -> worker.calculatePension())
            .toList();
    pensionFunds.forEach(pensionFund -> {
    System.out.println(pensionFund.getName() + "Ср. пенсия = " + pensionFund.calculateMedianPension());
    });
    System.out.printf("%.1f%n",pensionList.stream().reduce(Double::sum).get() / pensionList.size());


    List<Double> pensionList1 = pensionFunds.stream()
            .filter(Objects::nonNull)
            .flatMap(fund -> fund.getPersons().stream())
            .filter(worker -> worker.getAge() < 25)
            .map(worker -> worker.calculatePension())
            .toList();
    System.out.println(Collections.max(pensionList1));

    Worker junger = pensionFunds.stream()
            .filter(Objects::nonNull)
            .flatMap(fund -> fund.getPersons().stream())
            .min(Comparator.comparingInt(worker -> worker.getAge()))
            .orElse(null);
    System.out.println(junger);

    }}
