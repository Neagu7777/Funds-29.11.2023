package Funds;

import java.awt.*;
import java.io.FileNotFoundException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;
import java.util.List;

public class PensionFund {


    private boolean isGovernmental;
    private final String creationDate;
    private List<Worker> persons;
    private static Map<DayOfWeek, Boolean> workDays = createWorkDays();
    private String name;
    private int age;

   

    public static Map<DayOfWeek, Boolean> createWorkDays(){
        Map<DayOfWeek, Boolean> workDays = new HashMap<>();
        workDays.put(DayOfWeek.MONDAY, true);
        workDays.put(DayOfWeek.TUESDAY, true);
        workDays.put(DayOfWeek.WEDNESDAY, true);
        workDays.put(DayOfWeek.THURSDAY, true);
        workDays.put(DayOfWeek.FRIDAY, true);
        workDays.put(DayOfWeek.SATURDAY, true);
        workDays.put(DayOfWeek.SUNDAY, true);
        return workDays;
    }

    public PensionFund(boolean isGovernmental, String creationDate, List<Funds.Worker> persons, String name, int age) {

        this.isGovernmental = isGovernmental;
        this.creationDate = creationDate;
        this.persons = persons;
        this.name = name;
        this.age = age;
        this.workDays = new HashMap<>();

    }

    public PensionFund(String string) throws FileNotFoundException {

        String[] arrayPensionFund = string.split(", ");

        this.name = arrayPensionFund[0];
        this.isGovernmental = Boolean.parseBoolean(arrayPensionFund[1]);
        this.creationDate = arrayPensionFund[2];
        this.persons = PersonGenerator(arrayPensionFund[3]);
//        this.persons = WorkerGenerator.generateWorkers();
    }

    private List<Worker> PersonGenerator(String s) {
        return persons;
    }


    public boolean isGovernmental() {
        return isGovernmental;
    }

    public void setGovernmental(boolean governmental) {
        isGovernmental = governmental;
    }

    public String getCreationDate() {
        return creationDate;
    }


    public List<Worker> getPersons() {
        return persons;
    }

    public void setPersons(List<Funds.Worker> persons) {
        this.persons = persons;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Map<DayOfWeek, Boolean> getWorkDays() {
        return workDays;
    }

    public void setWorkDays(Map<DayOfWeek, Boolean> workDays) {
        this.workDays = workDays;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PensionFund that = (PensionFund) o;
        return isGovernmental == that.isGovernmental && age == that.age && Objects.equals(creationDate, that.creationDate) && Objects.equals(persons, that.persons) && Objects.equals(workDays, that.workDays) && Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isGovernmental, creationDate, persons, workDays, name, age);
    }

    @Override
    public String toString() {
        return "PensionFund{" +
                "isGovernmental=" + isGovernmental +
                ", creationDate='" + creationDate + '\'' +
                ", persons=" + persons.size() +
                ", workDays=" + workDays +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }

    public void info() {
        if (persons == null) {
            return;
        }
        if (isGovernmental) {
            System.out.println("Государственный фонд, используется " + persons.size() / 1000 + " тысяч человек.");
        } else {
            System.out.println("Негосударственный фонд, используется " + persons.size() + " не тысяч человек.");
        }
    }

    public double calculatePensionFor(AbleToCalculatePension obj) {
        if (isGovernmental && isWorkDayToday()) {
            return obj.calculatePension();
        } else {
            return 0; // Деньги из фонда украли
        }

    }
    private boolean isWorkDayToday(){
        LocalDate localDate = LocalDate.now();
        DayOfWeek dayOfWeekNow = localDate.getDayOfWeek();
        if(workDays == null){
            return false;
        }
        boolean isWorkDay = workDays.get(dayOfWeekNow);
        return isWorkDay;
    }

    public double calculateMedianPension() {
        if (persons == null || persons.size() == 0) {
            return 0.0;
        }
        double sum = 0.0;

        for (Funds.Worker worker : persons) {
            sum += calculatePensionFor(worker);

        }
        return sum / persons.size();
    }
}


